package vannes.nantes.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

/*
 * Classe permettant d'�x�cuter les requetes sql sur la table membre
 */
public class Persistance {

	private DatabaseHelper dbhelper;
	private Context moncontext;
	private SQLiteDatabase database;

	// constructeur
	public Persistance(Context c) {
		moncontext = c;
	}

	// ouverture de la bdd
	public Persistance open() throws SQLException {
		dbhelper = new DatabaseHelper(moncontext);
		database = dbhelper.getWritableDatabase();
		return this;

	}

	// fermeture de la bdd
	public void close() {
		dbhelper.close();
	}

	// requete insertion
	public void insertData(Membre m,Adresse a) {
		String nom = m.getNom();
		String prenom = m.getPrenom();
		String email = m.getEmail();
		String numero=a.getNumero();
		String rue=a.getRue();
		String codePostale=String.valueOf(a.getCodepostale());
		String ville= a.getVille();

		ContentValues cv = new ContentValues();
		ContentValues cva = new ContentValues();

		cv.put(DatabaseHelper.MEMBRE_NOM, nom);
		cv.put(DatabaseHelper.MEMBRE_PRENOM, prenom);
		cv.put(DatabaseHelper.MEMBRE_EMAIL, email);
		database.insert(DatabaseHelper.TABLE_MEMBRE, null, cv);
		int i =this.lastIdInsert();

		cva.put(DatabaseHelper.ADRESSE_ID_PERS, i);
		cva.put(DatabaseHelper.ADRESSE_NUMERO,numero);
		cva.put(DatabaseHelper.ADRESSE_RUE, rue);
		cva.put(DatabaseHelper.ADRESSE_CODE_POSTALE,codePostale);
		cva.put(DatabaseHelper.ADRESSE_VILLE, ville);

		database.insert(DatabaseHelper.TABLE_ADRESSE, null, cva);
	}

	// requete de suppression
	public void deleteMembre(int id) {

		database.delete(DatabaseHelper.TABLE_MEMBRE, DatabaseHelper.MEMBRE_ID
				+ " = " + id, null);
		database.delete(DatabaseHelper.TABLE_ADRESSE, DatabaseHelper.ADRESSE_ID_PERS
				+ " = " + id, null);
	}

	// recuperation du dernier id ins�r�
	public int lastIdInsert() {

		final String MY_QUERY = "SELECT MAX(_id) FROM "
				+ DatabaseHelper.TABLE_MEMBRE;
		Cursor cur = database.rawQuery(MY_QUERY, null);
		cur.moveToFirst();
		int ID = cur.getInt(0);
		cur.close();
		return ID;

	}

	// requete de selection
	public Cursor select() {
		String selectQuery = "SELECT  * FROM " + DatabaseHelper.TABLE_MEMBRE + "," + DatabaseHelper.TABLE_ADRESSE + " WHERE "
				+"membre._id = adresse.id_personne " ;
		Cursor c = database.rawQuery(selectQuery, null);


		if (c != null) {
			c.moveToFirst();
		}
		//c.close();
		return c;

	}

}