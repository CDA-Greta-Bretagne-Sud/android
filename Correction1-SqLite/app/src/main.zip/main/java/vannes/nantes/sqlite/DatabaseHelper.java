package vannes.nantes.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * Cr�ation de la bdd
 */
public class DatabaseHelper extends SQLiteOpenHelper {

	 // TABLE INFORMATTION
	 public static final String TABLE_MEMBRE = "membre";
	public static final String TABLE_ADRESSE = "adresse";
	public static final String ADRESSE_ID = "_id";
	public static final String ADRESSE_ID_PERS = "id_personne";
	public static final String ADRESSE_NUMERO = "numero";
	public static final String ADRESSE_RUE = "rue";
	public static final String ADRESSE_CODE_POSTALE = "codepostale";
	public static final String ADRESSE_VILLE = "ville";
	 public static final String MEMBRE_ID = "_id";
	 public static final String MEMBRE_PRENOM = "prenom";
	 public static final String MEMBRE_NOM = "nom";
	 public static final String MEMBRE_EMAIL = "email";

	 // DATABASE INFORMATION
	 static final String DB_NAME = "MEMBRE.DB";
	 static final int DB_VERSION = 2;

	 // TABLE CREATION STATEMENT

	 private static final String CREATE_TABLE = "create table " + TABLE_MEMBRE
	   + "(" + MEMBRE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
	   + MEMBRE_PRENOM + " TEXT NOT NULL ," + MEMBRE_NOM
	   + " TEXT NOT NULL ," + MEMBRE_EMAIL
	   + " TEXT NOT NULL);";

	private static final String CREATE_TABLE_ADRESSE = "create table " + TABLE_ADRESSE
			+ "(" + ADRESSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ ADRESSE_NUMERO + " TEXT NOT NULL ," + ADRESSE_RUE
			+ " TEXT NOT NULL ,"+ ADRESSE_CODE_POSTALE + " INTEGER NOT NULL ,"
			+ ADRESSE_VILLE + " TEXT NOT NULL ,"+ ADRESSE_ID_PERS
			+ " INTEGER NOT NULL);";

	 public DatabaseHelper(Context context) {
	  super(context, DB_NAME, null, DB_VERSION);

	 }

	 @Override
	 //creation table membre
	 public void onCreate(SQLiteDatabase db) {

	  db.execSQL(CREATE_TABLE);
		 db.execSQL(CREATE_TABLE_ADRESSE);
	 }

	 @Override
	 //en cas de mis a jour li� au changement de version-drop et create
	 public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	  db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEMBRE);
		 db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADRESSE);
	  onCreate(db);

	 }

	}
